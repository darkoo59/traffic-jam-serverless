from flaskwsk.handle import invoke
__all__ = [ 'invoke']
__version__ = '0.1.0'
