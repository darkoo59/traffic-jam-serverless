from flaskwsk import invoke
from web import app

def main(args):
   return invoke(app,args)
